package hide92795.novelengine.filecreator;

/**
 * 他クラスから利用される機能を提供します。
 * 
 * @author hide92795
 */
public class Utils {
	/**
	 * 最大公約数を計算し、返します。
	 * 
	 * @param a
	 *            最大公約数を求める数
	 * @param b
	 *            最大公約数を求める数
	 * @return 最大公約数
	 */
	public static int gcd(int a, int b) {
		if (b == 0) {
			return a;
		} else {
			return gcd(b, a % b);
		}
	}
}
