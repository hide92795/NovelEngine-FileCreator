/**
 * 背景範囲を表すフィギュアを保存するためのクラスが含まれます。
 *
 * @author hide92795
 */
package hide92795.novelengine.filecreator.saver.figure;